<template lang="">
    <div class="w-full text-center text-white bg-[url('https://via.placeholder.com/1920x320/002')] bg-center">
        <div class="py-24">
            <h3 class="text-2xl mb-2">온라인 문의</h3>
            <p class="text-gray-500 mb-2">궁금하신 내용이 있다면 게시판에 문의해주세요.</p>
            <router-link to="/service/online" class="inline-block py-2.5 px-8 bg-slate-800 hover:bg-slate-600 text-white rounded-md">온라인 문의</router-link>
        </div>
    </div>
</template>
<script>
export default {
    name: "HomeOnline"
}
</script>
<style lang="">
    
</style>